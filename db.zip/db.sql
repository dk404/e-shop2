-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               5.7.13 - MySQL Community Server (GPL)
-- ОС Сервера:                   Win64
-- HeidiSQL Версия:              9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Дамп структуры для таблица e-shop2.bigSlider
CREATE TABLE IF NOT EXISTS `bigSlider` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `nomer` int(3) NOT NULL DEFAULT '0',
  `stranica` varchar(50) DEFAULT NULL,
  `photo` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='универсальная таблица для хранения картинок для слайдера';

-- Дамп данных таблицы e-shop2.bigSlider: ~0 rows (приблизительно)
/*!40000 ALTER TABLE `bigSlider` DISABLE KEYS */;
/*!40000 ALTER TABLE `bigSlider` ENABLE KEYS */;


-- Дамп структуры для таблица e-shop2.brands
CREATE TABLE IF NOT EXISTS `brands` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `nomer` int(3) NOT NULL,
  `title` varchar(250) NOT NULL,
  `photo` varchar(250) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e-shop2.brands: ~0 rows (приблизительно)
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;


-- Дамп структуры для таблица e-shop2.categories
CREATE TABLE IF NOT EXISTS `categories` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `title` varchar(180) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e-shop2.categories: ~0 rows (приблизительно)
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;


-- Дамп структуры для таблица e-shop2.page_settings
CREATE TABLE IF NOT EXISTS `page_settings` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `stranica` varchar(180) NOT NULL DEFAULT '0',
  `title` varchar(180) NOT NULL DEFAULT '0',
  `btn_title` varchar(180) NOT NULL DEFAULT '0',
  `meta` text NOT NULL,
  `text` text NOT NULL,
  `dop_settings` text NOT NULL COMMENT 'json',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `stranica` (`stranica`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e-shop2.page_settings: ~4 rows (приблизительно)
/*!40000 ALTER TABLE `page_settings` DISABLE KEYS */;
REPLACE INTO `page_settings` (`ID`, `stranica`, `title`, `btn_title`, `meta`, `text`, `dop_settings`) VALUES
	(10, 'home', 'Home', 'home', '{"title":"sds dsd sd","desc":"s sd sd sd s","keywords":"d sd sd sd sd sd "}', '&lt;h2&gt;Why do we use it?&lt;/h2&gt;\r\n\r\n&lt;p&gt;It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &amp;#39;Content here, content here&amp;#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &amp;#39;lorem ipsum&amp;#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).&lt;/p&gt;\r\n', ''),
	(11, 'register', 'Completely Free Account', 'register', '{"title":"\\u0420\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044f","desc":"register","keywords":"\\u044b\\u0432\\u044b\\u0432\\u044b \\u044b\\u0432 \\u044b\\u0432\\u044b \\u0432 \\u044b\\u0432"}', '<p>8888tesque neque leo, dictum sit amet accumsan non, dignissim ac mauris. Mauris rhoncus, lectus tincidunt tempus aliquam, odio libero tincidunt metus, sed euismod elit enim ut mi. Nulla porttitor et dolor sed condimentum. Praesent porttitor lorem dui, in pulvinar enim rhoncus vitae. Curabitur tincidunt, turpis ac lobortis hendrerit, ex elit vestibulum est, at faucibus erat ligula non neque.</p>\r\n', ''),
	(12, 'login', 'Заведите новый аккаунт', 'login', '{"title":"\\u0410\\u0432\\u0442\\u043e\\u0440\\u0438\\u0437\\u0430\\u0446\\u0438\\u044f","desc":"\\u044b\\u0432\\u044b \\u0432\\u044b\\u0432 \\u044b\\u0432 \\u044b","keywords":"\\u0432 \\u044b\\u0432 \\u044b\\u0432 \\u044b\\u0432 \\u044b\\u0432 "}', '<p>Когда вы создаете&nbsp;<strong>новый</strong>&nbsp;<strong>аккаунт</strong>&nbsp;в любом сервисе данной компании, вы&nbsp;этим&nbsp;<strong>...&nbsp;</strong>Даже при регистрации с мобильного вы сможете также, например,&nbsp;<strong>завести</strong>&nbsp;Гугл Докс&nbsp;<strong>...</strong>Напомним, что регистрация&nbsp;<strong>аккаунта</strong>&nbsp;в Гугле&nbsp;<strong>бесплатна</strong>, однако оплата&nbsp;за трафик...</p>\r\n', ''),
	(13, 'contact', 'Контактная информация', 'contact', '{"title":"\\u041a\\u043e\\u043d\\u0442\\u0430\\u043a\\u0442\\u043d\\u0430\\u044f \\u0438\\u043d\\u0444\\u043e\\u0440\\u043c\\u0430\\u0446\\u0438\\u044f","desc":"dsdsds","keywords":"sds sds d sd "}', '<p>praesentium voluptatum deleniti atque corrupti quos dolores et quas. At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas.At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas.</p>\r\n', '{"address":"Lorem ipsum dolor, TL 19034-88974","phone":"+123456789","email":"dsdsd@sdsdsd.com","hours":"Monday-Friday, 7AM-5PM","map":"<iframe src=\\\\\\"https:\\/\\/www.google.com\\/maps\\/embed?pb=!1m18!1m12!1m3!1d37494223.23909492!2d103!3d55!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x453c569a896724fb%3A0x1409fdf86611f613!2sRussia!5e0!3m2!1sen!2sin!4v1415776049771\\\\\\"><\\/iframe>"}');
/*!40000 ALTER TABLE `page_settings` ENABLE KEYS */;


-- Дамп структуры для таблица e-shop2.products
CREATE TABLE IF NOT EXISTS `products` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `date` varchar(250) NOT NULL DEFAULT '0',
  `type` int(2) NOT NULL DEFAULT '0' COMMENT '1 - муж; 2 - жен;',
  `cat_id` int(5) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '0',
  `photo` varchar(250) NOT NULL DEFAULT '0',
  `price` varchar(250) NOT NULL DEFAULT '0',
  `price_2` varchar(250) NOT NULL DEFAULT '0' COMMENT 'цена со скидкой',
  `text` text,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e-shop2.products: 0 rows
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
/*!40000 ALTER TABLE `products` ENABLE KEYS */;


-- Дамп структуры для таблица e-shop2.users
CREATE TABLE IF NOT EXISTS `users` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `email` varchar(250) NOT NULL DEFAULT '0',
  `pass` varchar(250) NOT NULL DEFAULT '0',
  `nickname` varchar(250) NOT NULL DEFAULT '0',
  `date` bigint(11) NOT NULL DEFAULT '0',
  `status` int(2) NOT NULL DEFAULT '1' COMMENT '1 - просто пользователь; 2 - модератор; 3 - админ;',
  `phone` varchar(250) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e-shop2.users: ~0 rows (приблизительно)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
REPLACE INTO `users` (`ID`, `email`, `pass`, `nickname`, `date`, `status`, `phone`) VALUES
	(2, 'sht_job@ukr.net', '202cb962ac59075b964b07152d234b70', 'sht', 1469117205, 3, '+380934669146');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
