-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               5.5.41-log - MySQL Community Server (GPL)
-- Операционная система:         Win32
-- HeidiSQL Версия:              9.3.0.5049
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Дамп структуры для таблица e-shop2.page_settings
CREATE TABLE IF NOT EXISTS `page_settings` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `stranica` varchar(180) NOT NULL DEFAULT '0',
  `title` varchar(180) NOT NULL DEFAULT '0',
  `btn_title` varchar(180) NOT NULL DEFAULT '0',
  `meta` text NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `stranica` (`stranica`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e-shop2.page_settings: ~0 rows (приблизительно)
/*!40000 ALTER TABLE `page_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `page_settings` ENABLE KEYS */;

-- Дамп структуры для таблица e-shop2.socials
CREATE TABLE IF NOT EXISTS `socials` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `item_type` varchar(50) NOT NULL DEFAULT '0',
  `item_val` varchar(250) NOT NULL DEFAULT '0',
  `nomer` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `item_type` (`item_type`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='таблица для хранения ссылок на соц сети';

-- Дамп данных таблицы e-shop2.socials: ~0 rows (приблизительно)
/*!40000 ALTER TABLE `socials` DISABLE KEYS */;
REPLACE INTO `socials` (`ID`, `item_type`, `item_val`, `nomer`) VALUES
	(1, 'tw', 'https%3A%2F%2Fvk.com%2Fdoc29354273_437548766%3Fhash%3D411011c936159b8cc8%26amp%3Bdl%3Dbf4fc28799c587bec1', 0),
	(2, 'fb', '', 0),
	(3, 'be', 'https%3A%2F%2Fvk.com%2Fdoc29354273_437548766%3Fhash%3D411011c936159b8cc8%26amp%3Bdl%3Dbf4fc28799c587bec1111111', 0),
	(4, 'in', '', 0);
/*!40000 ALTER TABLE `socials` ENABLE KEYS */;

-- Дамп структуры для таблица e-shop2.users
CREATE TABLE IF NOT EXISTS `users` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `email` varchar(250) NOT NULL DEFAULT '0',
  `pass` varchar(250) NOT NULL DEFAULT '0',
  `nickname` varchar(250) NOT NULL DEFAULT '0',
  `phone` varchar(250) NOT NULL DEFAULT '0',
  `date` bigint(11) NOT NULL DEFAULT '0',
  `status` int(2) NOT NULL DEFAULT '1' COMMENT '1 - просто пользователь; 2 - модератор; 3 - админ;',
  `avatar` varchar(250) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e-shop2.users: ~1 rows (приблизительно)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
REPLACE INTO `users` (`ID`, `email`, `pass`, `nickname`, `phone`, `date`, `status`, `avatar`) VALUES
	(3, 'sht_job@ukr.net', '202cb962ac59075b964b07152d234b70', 'sht', '+38093000000', 1467299246, 3, '0');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
