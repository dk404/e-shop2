-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               5.5.48 - MySQL Community Server (GPL)
-- ОС Сервера:                   Win32
-- HeidiSQL Версия:              9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Дамп структуры для таблица e-shop2.bigSlider
CREATE TABLE IF NOT EXISTS `bigSlider` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `nomer` int(3) NOT NULL DEFAULT '0',
  `stranica` varchar(50) DEFAULT NULL,
  `photo` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='универсальная таблица для хранения картинок для слайдера';

-- Дамп данных таблицы e-shop2.bigSlider: ~0 rows (приблизительно)
/*!40000 ALTER TABLE `bigSlider` DISABLE KEYS */;
/*!40000 ALTER TABLE `bigSlider` ENABLE KEYS */;


-- Дамп структуры для таблица e-shop2.brands
CREATE TABLE IF NOT EXISTS `brands` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `nomer` int(5) NOT NULL DEFAULT '0',
  `photo` varchar(50) NOT NULL,
  `href` varchar(250) NOT NULL,
  `href_title` varchar(250) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e-shop2.brands: ~4 rows (приблизительно)
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
REPLACE INTO `brands` (`ID`, `nomer`, `photo`, `href`, `href_title`) VALUES
	(2, 1, '0136ef3feb2e5018278473e45cc5ee2a.png', 'http%3A%2F%2Fb%2Fe-shop2%2Fadm%2Fpartners.php', 'sacsacsac'),
	(3, 2, 'da687e66dfc04f81b1b9ab36f8af9a16.png', '%23', 'yjhgj'),
	(4, 3, '502aa9064618eff43b351f57f7c5b18d.png', '%23', 'ghfcghfmgjhf'),
	(5, 0, '09e6f7b003a1446e26ac5b3a812ac9d1.png', '%23', 'nfhjgfjhgjh');
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;


-- Дамп структуры для таблица e-shop2.categories
CREATE TABLE IF NOT EXISTS `categories` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `title` varchar(220) NOT NULL,
  `nomer` varchar(220) NOT NULL,
  `group_id` int(5) NOT NULL,
  `parent_id` int(5) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e-shop2.categories: ~0 rows (приблизительно)
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
REPLACE INTO `categories` (`ID`, `title`, `nomer`, `group_id`, `parent_id`) VALUES
	(1, 'Cute Kittens', '', 2, 0),
	(2, 'Sofa Cum Beds', '', 2, 1),
	(3, 'fgfgfgfgfgfg', '', 2, 0),
	(4, 'fgfgfgfgfgfg', '', 2, 0);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;


-- Дамп структуры для таблица e-shop2.gallery
CREATE TABLE IF NOT EXISTS `gallery` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `product_id` int(5) NOT NULL,
  `photo` varchar(220) NOT NULL,
  `nomer` int(5) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e-shop2.gallery: ~0 rows (приблизительно)
/*!40000 ALTER TABLE `gallery` DISABLE KEYS */;
/*!40000 ALTER TABLE `gallery` ENABLE KEYS */;


-- Дамп структуры для таблица e-shop2.groups
CREATE TABLE IF NOT EXISTS `groups` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `nomer` int(5) NOT NULL DEFAULT '0',
  `title` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e-shop2.groups: ~2 rows (приблизительно)
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
REPLACE INTO `groups` (`ID`, `nomer`, `title`) VALUES
	(1, 1, 'Women'),
	(2, 0, 'Men');
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;


-- Дамп структуры для таблица e-shop2.page_settings
CREATE TABLE IF NOT EXISTS `page_settings` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `stranica` varchar(180) NOT NULL DEFAULT '0',
  `title` varchar(180) NOT NULL DEFAULT '0',
  `btn_title` varchar(180) NOT NULL DEFAULT '0',
  `meta` text NOT NULL,
  `text` text NOT NULL,
  `dopRows` text NOT NULL COMMENT 'дополнительные кастомные поля json',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `stranica` (`stranica`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e-shop2.page_settings: ~5 rows (приблизительно)
/*!40000 ALTER TABLE `page_settings` DISABLE KEYS */;
REPLACE INTO `page_settings` (`ID`, `stranica`, `title`, `btn_title`, `meta`, `text`, `dopRows`) VALUES
	(1, 'home', 'home', 'home', '{"title":"f34rf4r3f","desc":"34rf43","keywords":"34tgg4"}', '&lt;p&gt;5yh46g6y5tr4&lt;/p&gt;\r\n', ''),
	(2, 'login', 'авторизация', 'логин', '{"title":"\\u0430\\u0432\\u0442\\u043e\\u0440\\u0438\\u0437\\u0430\\u0446\\u0438\\u044f \\u0430\\u0432\\u0442\\u043e\\u0440\\u0438\\u0437\\u0430\\u0446\\u0438\\u044f","desc":"\\u0432\\u044b\\u044b \\u044b\\u0432\\u044b \\u0432","keywords":"\\u0432\\u044b\\u0432 \\u044b\\u0432\\u044b\\u0432 \\u044b\\u0432 "}', '<p><strong>orem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n', ''),
	(3, 'register', 'регистрация', 'регистр', '{"title":"\\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044f \\u0440\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044f","desc":"\\u0432\\u044b\\u0440\\u0444\\u044b\\u0444","keywords":"\\u0444\\u044b\\u0432\\u044b\\u0444\\u0432\\u044b"}', '<p>Вже давно відомо, що читабельний зміст буде заважати зосередитись людині, яка оцінює композицію сторінки. Сенс використання Lorem Ipsum полягає в тому, що цей текст має більш-менш нормальне розподілення літер на відміну від, наприклад, &quot;Тут іде текст. Тут іде текст.&quot; Це робить текст схожим на оповідний. Багато програм верстування та веб-дизайну використовують Lorem Ipsum як зразок і пошук за терміном &quot;lorem ipsum&quot; відкриє багато веб-сайтів, які знаходяться ще в зародковому стані. Різні версії Lorem Ipsum з&#39;явились за минулі роки, деякі випадково, деякі було створено зумисно (зокрема, жартівливі).</p>\r\n', ''),
	(6, 'contact', 'Де собі взяти трохи?', 'contact', '{"title":"\\u043a\\u043e\\u043d\\u0442\\u0430\\u043a\\u0442\\u044b\\u043a\\u043e\\u043d\\u0442\\u0430\\u043a\\u0442\\u044b","desc":"\\u0432\\u0439\\u0446\\u0432\\u0446\\u0439\\u0432","keywords":"\\u0439\\u0446\\u0432\\u0446\\u0439\\u0432\\u0439\\u0446\\u0432\\u0446\\u0439\\u0432"}', '<p>Існує багато варіацій уривків з Lorem Ipsum, але більшість з них зазнала певних змін на кшталт жартівливих вставок або змішування слів, які навіть не виглядають правдоподібно. Якщо ви збираєтесь використовувати Lorem Ipsum, ви маєте упевнитись в тому, що всередині тексту не приховано нічого, що могло б викликати у читача конфуз. Більшість відомих генераторів Lorem Ipsum в Мережі генерують текст шляхом повторення наперед заданих послідовностей Lorem Ipsum. Принципова відмінність цього генератора робить його першим справжнім генератором Lorem Ipsum. Він використовує словник з більш як 200 слів латини та цілий набір моделей речень - це дозволяє генерувати Lorem Ipsum, який виглядає осмислено. Таким чином, згенерований Lorem Ipsum не міститиме повторів, жартів, нехарактерних для латини слів і т.ін.</p>\r\n', '{"address":"TL 19034-88974","phone":"+0123456789","email":"http:\\/\\/uk.lipsum.com\\/","hours":"7AM-5PM","maps":"<iframe src=\\\\\\"https:\\/\\/www.google.com\\/maps\\/embed?pb=!1m18!1m12!1m3!1d2617.2343182982368!2d33.64885332583404!3d49.00612696346177!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40d9ff08d82816d9%3A0xbf7f51cf999d95aa!2z0LLRg9C70LjRhtGPINCf0L7RgNGC0L7QstCwLCAxLCDQk9C-0YDRltGI0L3RliDQv9C70LDQstC90ZYsINCf0L7Qu9GC0LDQstGB0YzQutCwINC-0LHQu9Cw0YHRgtGM!5e0!3m2!1sru!2sua!4v1468669869186\\\\\\" width=\\\\\\"800\\\\\\" height=\\\\\\"600\\\\\\" frameborder=\\\\\\"0\\\\\\" style=\\\\\\"border:0\\\\\\" allowfullscreen><\\/iframe>"}'),
	(13, 'product', '', 'Продукт', '{"title":"product","desc":"\\u0443\\u0443\\u043a\\u0430\\u0443\\u043a\\u0430\\u0446\\u0443\\u043a\\u043a\\u0430\\u0446\\u0443","keywords":"\\u0446\\u0443\\u0430\\u0446\\u0443\\u0430\\u0446\\u0443\\u0430\\u0443\\u0446\\u0430\\u0443\\u0446"}', '', '');
/*!40000 ALTER TABLE `page_settings` ENABLE KEYS */;


-- Дамп структуры для таблица e-shop2.products
CREATE TABLE IF NOT EXISTS `products` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `cat_id` int(5) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '0',
  `photo` varchar(250) NOT NULL DEFAULT '0',
  `price` varchar(250) NOT NULL DEFAULT '0',
  `price_2` varchar(250) NOT NULL DEFAULT '0' COMMENT 'цена со скидкой',
  `text1` text,
  `text2` text,
  `text3` text,
  `group_id` int(5) NOT NULL,
  `brand_id` int(5) NOT NULL,
  `discount_perents` varchar(250) NOT NULL COMMENT 'cкидка в %',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e-shop2.products: 0 rows
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
/*!40000 ALTER TABLE `products` ENABLE KEYS */;


-- Дамп структуры для таблица e-shop2.socials
CREATE TABLE IF NOT EXISTS `socials` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) DEFAULT '0',
  `link` varchar(250) DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e-shop2.socials: ~4 rows (приблизительно)
/*!40000 ALTER TABLE `socials` DISABLE KEYS */;
REPLACE INTO `socials` (`ID`, `type`, `link`) VALUES
	(1, 'tw', 'http%3A%2F%2Fmakefuture.net%2Farticle%2Fmysql-all-reserved-words%2F'),
	(2, 'fb', ''),
	(3, 'be', ''),
	(4, 'in', 'http%3A%2F%2Fmakefuture.net%2Farticle%2Fmysql-all-reserved-words%2F');
/*!40000 ALTER TABLE `socials` ENABLE KEYS */;


-- Дамп структуры для таблица e-shop2.text_slider
CREATE TABLE IF NOT EXISTS `text_slider` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `nomer` int(5) NOT NULL DEFAULT '0',
  `big_title` varchar(250) DEFAULT '0',
  `stranica` varchar(250) DEFAULT '0',
  `small_title1` text,
  `small_title2` text,
  `photo` varchar(250) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e-shop2.text_slider: ~2 rows (приблизительно)
/*!40000 ALTER TABLE `text_slider` DISABLE KEYS */;
REPLACE INTO `text_slider` (`ID`, `nomer`, `big_title`, `stranica`, `small_title1`, `small_title2`, `photo`) VALUES
	(2, 1, 'sdsd sd sdsd sd ', 'home', '["\\u0432\\u044b\\u0432 \\u044b\\u0432 \\u044b\\u0432 \\u044b\\u0432 \\u044b\\u0432 "]', '["ppppppppppppppp"]', '1c9a13b6beea390f4dfd0c82205725ef.jpeg'),
	(3, 0, 'рпаопор', 'home', '["\\u043e\\u0440\\u0430\\u043f\\u043e\\u0440\\u043f\\u0430\\u0440","\\u043e\\u0440\\u0430\\u043f\\u043f\\u043e\\u0440\\u0430\\u043f\\u043e\\u0440"]', '["\\u043e\\u0440\\u0430\\u043f\\u043e\\u0440\\u0440\\u043f\\u043e"]', 'c5f98f29a58466206894abc87f6f7da9.jpeg');
/*!40000 ALTER TABLE `text_slider` ENABLE KEYS */;


-- Дамп структуры для таблица e-shop2.users
CREATE TABLE IF NOT EXISTS `users` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `email` varchar(250) NOT NULL DEFAULT '0',
  `pass` varchar(250) NOT NULL DEFAULT '0',
  `nickname` varchar(250) NOT NULL DEFAULT '0',
  `phone` varchar(250) NOT NULL DEFAULT '0',
  `date` bigint(11) NOT NULL DEFAULT '0',
  `status` int(2) NOT NULL DEFAULT '1' COMMENT '1 - просто пользователь; 2 - модератор; 3 - админ;',
  `avatar` varchar(250) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e-shop2.users: ~1 rows (приблизительно)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
REPLACE INTO `users` (`ID`, `email`, `pass`, `nickname`, `phone`, `date`, `status`, `avatar`) VALUES
	(3, 'kimkim000@yandex.ru', '202cb962ac59075b964b07152d234b70', 'kimkim000', '+380937901698', 1467462274, 3, '0');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
