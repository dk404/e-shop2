-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               5.5.48 - MySQL Community Server (GPL)
-- ОС Сервера:                   Win32
-- HeidiSQL Версия:              9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Дамп структуры для таблица e-shop2.bigSlider
CREATE TABLE IF NOT EXISTS `bigSlider` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `nomer` int(3) NOT NULL DEFAULT '0',
  `stranica` varchar(50) DEFAULT NULL,
  `photo` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='универсальная таблица для хранения картинок для слайдера';

-- Дамп данных таблицы e-shop2.bigSlider: ~0 rows (приблизительно)
/*!40000 ALTER TABLE `bigSlider` DISABLE KEYS */;
/*!40000 ALTER TABLE `bigSlider` ENABLE KEYS */;


-- Дамп структуры для таблица e-shop2.categories
CREATE TABLE IF NOT EXISTS `categories` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `title` varchar(180) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e-shop2.categories: ~0 rows (приблизительно)
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;


-- Дамп структуры для таблица e-shop2.page_settings
CREATE TABLE IF NOT EXISTS `page_settings` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `stranica` varchar(180) NOT NULL DEFAULT '0',
  `title` varchar(180) NOT NULL DEFAULT '0',
  `btn_title` varchar(180) NOT NULL DEFAULT '0',
  `meta` text NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `stranica` (`stranica`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e-shop2.page_settings: ~1 rows (приблизительно)
/*!40000 ALTER TABLE `page_settings` DISABLE KEYS */;
REPLACE INTO `page_settings` (`ID`, `stranica`, `title`, `btn_title`, `meta`, `text`) VALUES
	(1, 'home', 'home', 'home', '{"title":"f34rf4r3f","desc":"34rf43","keywords":"34tgg4"}', '&lt;p&gt;5yh46g6y5tr4&lt;/p&gt;\r\n');
/*!40000 ALTER TABLE `page_settings` ENABLE KEYS */;


-- Дамп структуры для таблица e-shop2.products
CREATE TABLE IF NOT EXISTS `products` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `date` varchar(250) NOT NULL DEFAULT '0',
  `type` int(2) NOT NULL DEFAULT '0' COMMENT '1 - муж; 2 - жен;',
  `cat_id` int(5) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '0',
  `photo` varchar(250) NOT NULL DEFAULT '0',
  `price` varchar(250) NOT NULL DEFAULT '0',
  `price_2` varchar(250) NOT NULL DEFAULT '0' COMMENT 'цена со скидкой',
  `text` text,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e-shop2.products: 0 rows
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
/*!40000 ALTER TABLE `products` ENABLE KEYS */;


-- Дамп структуры для таблица e-shop2.socials
CREATE TABLE IF NOT EXISTS `socials` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) DEFAULT '0',
  `link` varchar(250) DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e-shop2.socials: ~4 rows (приблизительно)
/*!40000 ALTER TABLE `socials` DISABLE KEYS */;
REPLACE INTO `socials` (`ID`, `type`, `link`) VALUES
	(1, 'tw', 'http%3A%2F%2Fmakefuture.net%2Farticle%2Fmysql-all-reserved-words%2F'),
	(2, 'fb', ''),
	(3, 'be', ''),
	(4, 'in', 'http%3A%2F%2Fmakefuture.net%2Farticle%2Fmysql-all-reserved-words%2F');
/*!40000 ALTER TABLE `socials` ENABLE KEYS */;


-- Дамп структуры для таблица e-shop2.text_slider
CREATE TABLE IF NOT EXISTS `text_slider` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `nomer` int(5) NOT NULL DEFAULT '0',
  `big_title` varchar(250) DEFAULT '0',
  `stranica` varchar(250) DEFAULT '0',
  `small_title1` text,
  `small_title2` text,
  `photo` varchar(250) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e-shop2.text_slider: ~1 rows (приблизительно)
/*!40000 ALTER TABLE `text_slider` DISABLE KEYS */;
REPLACE INTO `text_slider` (`ID`, `nomer`, `big_title`, `stranica`, `small_title1`, `small_title2`, `photo`) VALUES
	(2, 0, 'sdsd sd sdsd sd ', 'home', '["\\u0432\\u044b\\u0432 \\u044b\\u0432 \\u044b\\u0432 \\u044b\\u0432 \\u044b\\u0432 "]', '["ppppppppppppppp"]', '1c9a13b6beea390f4dfd0c82205725ef.jpeg');
/*!40000 ALTER TABLE `text_slider` ENABLE KEYS */;


-- Дамп структуры для таблица e-shop2.users
CREATE TABLE IF NOT EXISTS `users` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `email` varchar(250) NOT NULL DEFAULT '0',
  `pass` varchar(250) NOT NULL DEFAULT '0',
  `nickname` varchar(250) NOT NULL DEFAULT '0',
  `phone` varchar(250) NOT NULL DEFAULT '0',
  `date` bigint(11) NOT NULL DEFAULT '0',
  `status` int(2) NOT NULL DEFAULT '1' COMMENT '1 - просто пользователь; 2 - модератор; 3 - админ;',
  `avatar` varchar(250) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы e-shop2.users: ~1 rows (приблизительно)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
REPLACE INTO `users` (`ID`, `email`, `pass`, `nickname`, `phone`, `date`, `status`, `avatar`) VALUES
	(3, 'kimkim000@yandex.ru', '202cb962ac59075b964b07152d234b70', 'kimkim000', '+380937901698', 1467462274, 3, '0');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
